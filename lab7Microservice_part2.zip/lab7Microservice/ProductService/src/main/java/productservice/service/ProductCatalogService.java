package productservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import productservice.domain.Product;
import productservice.service.dto.ProductChangeEventDTO;
import productservice.repository.ProductRepository;
import productservice.service.dto.ProductAdapter;
import productservice.service.dto.ProductDTO;

@Service
public class ProductCatalogService implements IProductCatalogService {
	@Autowired
	ProductRepository productRepository;
	@Autowired
	private ApplicationEventPublisher publisher;


	@Override
	public void addProduct(ProductDTO productDto) {
		Product product = ProductAdapter.getProduct(productDto);
		//check if product exists
		Optional<Product> result = productRepository.findById(product.getProductnumber());
		if (result.isPresent())
			publisher.publishEvent(new ProductChangeEventDTO(productDto));
		productRepository.save(product);
		
	}
	@Override
	public ProductDTO getProduct(String productnumber) {
		Optional<Product> result = productRepository.findById(productnumber);
		if (result.isPresent())
		  return ProductAdapter.getProductDTO(result.get());
		else
			return null;
	}
}
