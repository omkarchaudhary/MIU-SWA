package productservice.service;

import productservice.service.dto.ProductDTO;

public interface IProductCatalogService {
    void addProduct(ProductDTO productDto);

    ProductDTO getProduct(String productnumber);
}
