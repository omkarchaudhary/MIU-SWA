package shoppingservice.service;

import shoppingservice.service.dto.ProductDTO;

public interface IProductCatalogService {
    void addProduct(ProductDTO productDto);

    ProductDTO getProduct(String productnumber);
}
