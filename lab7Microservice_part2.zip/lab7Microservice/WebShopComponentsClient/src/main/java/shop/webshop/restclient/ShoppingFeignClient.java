package shop.webshop.restclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import shop.webshop.dto.ShoppingCartDTO;

@FeignClient(name = "ShoppingService")
public interface ShoppingFeignClient {
    @PostMapping(value = "/cart/{cartId}/{productNumber}/{quantity}")
    public ResponseEntity<?> addToCart(@PathVariable String cartId, @PathVariable String productNumber, @PathVariable int quantity);

    @GetMapping("/cart/{cartId}")
    public ShoppingCartDTO getCart(@PathVariable String cartId);
}
