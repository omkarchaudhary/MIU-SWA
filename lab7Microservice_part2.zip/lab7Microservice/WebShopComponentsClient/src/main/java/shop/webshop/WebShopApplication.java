package shop.webshop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import shop.webshop.restclient.ProductFeignClient;
import shop.webshop.restclient.ShoppingFeignClient;
import shop.webshop.dto.ProductDTO;
import shop.webshop.dto.ShoppingCartDTO;


@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class WebShopApplication implements CommandLineRunner {
	@Autowired
	ProductFeignClient productFeignClient;
	@Autowired
	ShoppingFeignClient shoppingFeignClient;

	public static void main(String[] args) {
		SpringApplication.run(WebShopApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		//create products
		ProductDTO productDTO = new ProductDTO("A33","TV",450.0);
		productFeignClient.addProduct(productDTO);
		productDTO = new ProductDTO("A34","MP3 Player",75.0);
		productFeignClient.addProduct(productDTO);
		//restTemplate.postForLocation("http://localhost:8900/products", new ProductDTO("A33","TV",450.0));
		//restTemplate.postForLocation("http://localhost:8900/products", new ProductDTO("A34","MP3 Player",75.0));

		//add product to the shoppingcart
		//restTemplate.postForLocation("http://localhost:8901/cart/1/A33/3",null);
		shoppingFeignClient.addToCart("1","A33",3);
		//add product to the shoppingcart
		//restTemplate.postForLocation("http://localhost:8901/cart/1/A34/2", null);
		shoppingFeignClient.addToCart("1","A34",2);

		//get the shoppingcart
		//ShoppingCartDTO cart = restTemplate.getForObject("http://localhost:8901/cart/1", ShoppingCartDTO.class);
		ShoppingCartDTO cart = shoppingFeignClient.getCart("1");
		System.out.println("\n-----Shoppingcart-------");
		if (cart != null) cart.print();

		//change product price
		//restTemplate.postForLocation("http://localhost:8900/products", new ProductDTO("A33","TV",550.0));
		productDTO = new ProductDTO("A33","TV",75.0);
		productFeignClient.addProduct(productDTO);
		//get the shoppingcart
		//cart = restTemplate.getForObject("http://localhost:8901/cart/1", ShoppingCartDTO.class);
		cart = shoppingFeignClient.getCart("1");
		System.out.println("\n-----Shoppingcart after price change-------");
		if (cart != null) cart.print();
	}

}
