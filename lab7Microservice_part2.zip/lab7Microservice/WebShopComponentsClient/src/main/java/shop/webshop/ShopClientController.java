package shop.webshop;

import org.springframework.web.bind.annotation.*;

@RestController
public class ShopClientController {
//    @Autowired
//    ProductFeignClient productFeignClient;
//    @Autowired
//    ShoppingFeignClient shoppingFeignClient;
//
//    @PostMapping("/products")
//    public ResponseEntity<?> numberOfProductsInStock(@RequestBody ProductDTO productDTO) {
//        productFeignClient.addProduct(productDTO);
//        return new ResponseEntity<>(HttpStatus.OK);
//    }
//    @GetMapping("/cart/{cartId}")
//    public ResponseEntity<?> getCart(@PathVariable String cartId) {
//        ShoppingCartDTO cart = shoppingFeignClient.getCart(cartId);
//        return new ResponseEntity<>(cart, HttpStatus.OK);
//    }
//    @PostMapping(value = "/cart/{cartId}/{productNumber}/{quantity}")
//    public ResponseEntity<?> addToCart(@PathVariable String cartId, @PathVariable String productNumber, @PathVariable int quantity){
//        shoppingFeignClient.addToCart(cartId, productNumber, quantity);
//        return new ResponseEntity<ShoppingCartDTO>(HttpStatus.OK);
//    }
}
