package client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;



@SpringBootApplication
public class ClientApplication implements CommandLineRunner {
	@Autowired
	private RestOperations  restTemplate;

	public static void main(String[] args) {
		SpringApplication.run(ClientApplication.class, args);
	}

	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Override
	public void run(String... args) throws Exception {

		//create products
		restTemplate.postForLocation("http://localhost:8095/products", new ProductDTO("A33","TV",450.0));
		restTemplate.postForLocation("http://localhost:8095/products", new ProductDTO("A34","MP3 Player",75.0));

		//set the quantity
		restTemplate.postForLocation("http://localhost:8097/stocks", new StockDTO("A33",10));
		restTemplate.postForLocation("http://localhost:8097/stocks", new StockDTO("A34",4));

		//get the products from the query service
		ProductWithStockDTO product = restTemplate.getForObject("http://localhost:8096/products/A33", ProductWithStockDTO.class);
		System.out.println("-----Product 1-------");
		System.out.println(product);

		product = restTemplate.getForObject("http://localhost:8096/products/A34", ProductWithStockDTO.class);
		System.out.println("-----Product 2-------");
		System.out.println(product);

		//change the quantity
		restTemplate.put("http://localhost:8097/stocks/A33", new StockDTO("A33",5));
		restTemplate.put("http://localhost:8097/stocks/A34", new StockDTO("A34",2));

		//change a product
		restTemplate.put("http://localhost:8095/products/A33", new ProductDTO("A33","IPhone 12",450.0));

		//get the products from the query service
		product = restTemplate.getForObject("http://localhost:8096/products/A33", ProductWithStockDTO.class);
		System.out.println("-----Product 1-------");
		System.out.println(product);

		product = restTemplate.getForObject("http://localhost:8096/products/A34", ProductWithStockDTO.class);
		System.out.println("-----Product 2-------");
		System.out.println(product);
	}


}
