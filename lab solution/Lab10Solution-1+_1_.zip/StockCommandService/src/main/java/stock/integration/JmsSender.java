package stock.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import stock.service.StockChangeEventDTO;

@Component
public class JmsSender {
    @Autowired
    JmsTemplate jmsTemplate;

    public void sendMessage(StockChangeEventDTO stockChangeEventDTO)  {
        try {
            //convert person to JSON string
            ObjectMapper objectMapper = new ObjectMapper();
            String stockChangeEventDTOString = objectMapper.writeValueAsString(stockChangeEventDTO);
            System.out.println("Sending a JMS message:" + stockChangeEventDTOString);
            jmsTemplate.convertAndSend("stockchangeQueue", stockChangeEventDTOString);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
