package stock.service;

import stock.domain.Stock;

public class StockAdapter {
    public static Stock fromDTO(StockDTO dto){
        return new Stock(dto.getProductId(), dto.getNumberInStock());
    }
    public static StockDTO toDTO(Stock stock){
        return new StockDTO(stock.getProductId(), stock.getNumberInStock());
    }
}
