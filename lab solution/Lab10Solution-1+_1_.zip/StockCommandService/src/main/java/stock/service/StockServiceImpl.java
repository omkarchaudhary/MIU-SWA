package stock.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import stock.data.StockRepository;
import stock.domain.Stock;
import stock.integration.JmsSender;

import java.util.Optional;

@Service
public class StockServiceImpl implements StockService{
    @Autowired
    private StockRepository stockRepository;
    @Autowired
    private JmsSender jmsSender;

    @Override
    public void add(StockDTO stockDTO) {
        Stock stock = StockAdapter.fromDTO(stockDTO);
        stockRepository.save(stock);
        jmsSender.sendMessage(new StockChangeEventDTO(stockDTO.getProductId(), stockDTO.getNumberInStock()));
    }

    @Override
    public void delete(String product_id) {
        stockRepository.deleteById(product_id);
        jmsSender.sendMessage(new StockChangeEventDTO(product_id, 0));
    }

    @Override
    public void update(String product_id,StockDTO stockDTO) {
        Optional<Stock> optionalStock = stockRepository.findById(product_id);
        if (optionalStock.isPresent()){
            Stock stock = StockAdapter.fromDTO(stockDTO);
            stockRepository.save(stock);
            jmsSender.sendMessage(new StockChangeEventDTO(stockDTO.getProductId(), stockDTO.getNumberInStock()));
        }
    }
}
