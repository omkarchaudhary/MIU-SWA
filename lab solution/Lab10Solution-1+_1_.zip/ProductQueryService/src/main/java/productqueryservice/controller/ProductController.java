package productqueryservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import productqueryservice.service.ProductDTO;
import productqueryservice.service.ProductService;

@RestController
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping("/products/{product_id}")
    public ResponseEntity<?> get(@PathVariable String product_id){
        ProductDTO productDto = productService.get(product_id);
        return new ResponseEntity<>(productDto, HttpStatus.OK);
    }

}
