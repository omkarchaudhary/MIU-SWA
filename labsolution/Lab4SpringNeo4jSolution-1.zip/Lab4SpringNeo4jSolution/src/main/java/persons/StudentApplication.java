package persons;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;

import java.util.Arrays;
import java.util.List;

@SpringBootApplication
@EnableNeo4jRepositories
public class StudentApplication implements CommandLineRunner{
	
	@Autowired
	StudentRepository studentRepository;

	public static void main(String[] args) {
		SpringApplication.run(StudentApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		studentRepository.deleteAll();

		Student greg = new Student("Greg");
		Student roy = new Student("Roy");
		Student bob = new Student("Bob");

		Course swa = new Course("cs590", "Software Architecture");
		Course swe = new Course("cs475", "Software Engineering");
		Course asd = new Course("cs525", "Advanced Software Development");

		greg.addCourse(swa);
		greg.addCourse(swe);
		greg.addCourse(asd);

		roy.addCourse(swa);

		bob.addCourse(swa);
		bob.addCourse(asd);



		studentRepository.save(greg);
		studentRepository.save(roy);
		studentRepository.save(bob);


		Student student = studentRepository.findByName("Greg");
		System.out.println("Data from greg");
		System.out.println( student);

		List<Student> students = studentRepository.findByCourseNumber("cs590");
		System.out.println("All students who took Software Architecture");
		students.stream().forEach(s -> System.out.println( s.getName()));
	}
}
