
package persons;

import java.util.HashSet;
import java.util.Set;

import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;
import org.springframework.data.neo4j.core.schema.Relationship;
import org.springframework.data.neo4j.core.schema.GeneratedValue;

@Node
public class Student {

	@Id @GeneratedValue private Long id;

	private String name;

	@Relationship(type = "TAKES")
	public Set<Course> courses= new HashSet<>();

	private Student() {
	};

	public Student(String name) {
		this.name = name;
	}

	public void addCourse(Course course) {
		courses.add(course);
	}

	@Override
	public String toString() {
		return "Student{" +
				"id=" + id +
				", name='" + name + '\'' +
				", courses=" + courses +
				'}';
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
